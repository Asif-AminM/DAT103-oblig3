import static java.lang.Thread.sleep;

import static java.lang.Thread.sleep;

public class Writer implements Runnable {


    private TheSemaphore write;
    private Buffer buffer;
    private int number = 1;


    /**
     * @param write
     * @param buffer
     */
    public Writer(TheSemaphore write, Buffer buffer) {
        this.write = write;
        this.buffer = buffer;
    }

    @Override
    public void run() {
        do {
            write.vent();
            try{
                sleep(10);
            }catch (InterruptedException test) {
                test.printStackTrace();
            }
            buffer.skriv("skriv" + number);
            write.signal();
            try {
                sleep(10);
            }catch (InterruptedException test) {
                test.printStackTrace();
            }
            number++;
        } while (true);
    }

}
