import java.util.concurrent.Semaphore;
import java.util.concurrent.ThreadLocalRandom;
import java.util.stream.IntStream;

import static java.lang.System.*;

public class theDiningphilosophers {

    static int philosopher = 5;
    static theDiningphilosophers.chopstick chopsticks[] = new theDiningphilosophers.chopstick[philosopher];
    static theDiningphilosophers.philosopher philosophers[] = new theDiningphilosophers.philosopher[philosopher];

    public static class chopstick {

        public Semaphore mutex = new Semaphore(1);
        void release() {
            mutex.release();
        }


        void grab() {
            try {
                mutex.acquire ();
            } catch ( InterruptedException e ) {
                e.printStackTrace ( out );
            }
        }

        boolean check() {
            return mutex.availablePermits() > 0;
        }

    }


    static class philosopher extends Thread {

        public int number;
        public theDiningphilosophers.chopstick rightStick;
        public theDiningphilosophers.chopstick leftStick;

        /**
         * @param num
         * @param left
         * @param right
         */
        philosopher(int num, theDiningphilosophers.chopstick left, theDiningphilosophers.chopstick right) {
            number = num;
            leftStick = left;
            rightStick = right;
        }

        public void run(){

            while (true) {
                leftStick.grab();
                out.println((number + 1) );
                rightStick.grab();
                out.println((number + 1));
                eat();
                leftStick.release();
                out.println((number+1));
                rightStick.release();
                out.println( (number+1) );
            }
        }

        void eat() {
            try {
                var sleep = ThreadLocalRandom.current().nextInt( 0, 1000 );
                out.println( (number + 1) + sleep );
                Thread.sleep( sleep );
            } catch (InterruptedException e) {
                e.printStackTrace( out );
            }
        }

    }

    public static void main(String[] args) throws Exception {

        IntStream.range( 0, philosopher ).forEach( i -> chopsticks[i] = new theDiningphilosophers.chopstick () );

        int bound = philosopher;
        for (int i1 = 0; i1 < bound; i1++){
            philosophers[i1] = new theDiningphilosophers.philosopher ( i1 , chopsticks[i1] , chopsticks[(i1 + 1) % philosopher] );
            philosophers[i1].start ();
        }

        while (true) {

            Thread.sleep(1000);


            var laast = true;
            for (int i = 0, chopsticksLength = chopsticks.length; i < chopsticksLength; i++){
                theDiningphilosophers.chopstick ph;
                ph = chopsticks[i];
                if (ph.check()){
                    laast = false;
                    break;
                }
            }
            if (! laast){
            }
            Thread.sleep(1000);
            break;
        }

        out.println("done");
        exit(0);
    }
}
