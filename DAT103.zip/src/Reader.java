import static java.lang.System.out;
import static java.lang.Thread.sleep;

public class Reader implements Runnable {


    private TheSemaphore mutex;
    private TheSemaphore write;
    private Buffer buffer;
    private int id;



    @Override
    public void run() {
        while (true){
            mutex.vent ();
            buffer.setReadCount ( buffer.getReadCount () + 1 );
            if ( 1 == buffer.getReadCount () ) write.vent ();
            mutex.signal ();
            out.println ( id  + buffer.read () );
            mutex.vent ();
            buffer.setReadCount ( buffer.getReadCount () - 1 );
            if ( 0 != buffer.getReadCount () ){
            }else write.signal ();
            mutex.signal ();
            try {
                sleep ( 100 );
            } catch ( InterruptedException test ) {
                test.printStackTrace ();
            }


        }
    }
    public Reader(TheSemaphore mutex, TheSemaphore write, Buffer buffer, int id) {
        this.mutex = mutex;
        this.write = write;
        this.buffer = buffer;
        this.id = id;

    }

}
