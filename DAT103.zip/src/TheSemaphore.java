import static java.lang.Thread.sleep;

public class TheSemaphore {
    private int number;

    public TheSemaphore(int number) {
        this.number = number;
    }

    public void vent() {

        while (true){

            if (this.number > 0){

                break;
            }

            try {

                sleep( 50 );

            } catch (InterruptedException test) {

                test.printStackTrace();

            }
        }

        this.number--;
    }
    public void signal() {
        this.number++;
    }

    public int getnumber() {
        return this.number;
    }
}
