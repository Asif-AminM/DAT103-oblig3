public class Main {
    public static void main(String[] args) {
        TheSemaphore mutex;
        mutex = new TheSemaphore( 1);
        TheSemaphore write;
        write = new TheSemaphore( 1);
        Buffer buffer;
        buffer = new Buffer();

        new Thread ( new Writer ( write , buffer ) ).start ();
        new Thread ( new Reader ( mutex , write , buffer , 1 ) ).start ();
        new Thread ( new Reader ( mutex , write , buffer , 2 ) ).start ();
    }
}
