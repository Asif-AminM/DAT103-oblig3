import java.util.*;

public class Buffer {

    private List<String> list;
    private int readCount;
    private Random rand = new Random();


    /**
     *
     */
    public Buffer() {
        readCount = 0;
        list = new ArrayList<>();
    }


    public void skriv(String s) {

        list.add(s);
    }


    public void setReadCount() {
        setReadCount (  );
    }

    public void setReadCount(int cout) {
        this.readCount = cout;
    }

    public boolean listIsEmpty() {
        return list.isEmpty();
    }

    public List<String> getList() {
        return list;
    }

    public int getReadCount() {
        return readCount;
    }



    public String read() {
        int random = rand.nextInt(list.size());
        return list.get(random);
    }
}
